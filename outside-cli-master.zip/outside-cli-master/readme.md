# Outside

A CLI app that gives you the weather forecast.

_This is the source code for our tutorial on [building Node CLIs](https://timber.io/blog/creating-a-real-world-cli-app-with-node)._
